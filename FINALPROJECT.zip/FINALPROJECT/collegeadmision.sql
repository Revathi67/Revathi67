-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2022 at 05:54 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `collegeadmision`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `allcoursenames` ()  select crnm,crid from course$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `checkuser` (IN `em` VARCHAR(300), IN `pd` VARCHAR(10), OUT `ct` INT)  select count(*) into ct from users where email_id=em and pwd=pd$$$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leftoutfee` (IN `sid` INT)  select c.cost-s.feepay as leftoutfee from course c,student s where c.crnm=s.crnm and s.stid=sid$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `crid` int(11) NOT NULL,
  `crnm` varchar(300) NOT NULL,
  `cost` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `desp` longtext NOT NULL,
  `pic` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`crid`, `crnm`, `cost`, `duration`, `desp`, `pic`) VALUES
(100, 'Fullstack', '5898', '386hrs', 'Become a Full Stack Developer and learn how to build applications such as Swiggy, Quora, IMDB, and lots more. Start your Full Stack journey at Rs. 5,898 per month*. Eligibility: Bachelor?s Degree with 50%. Prior coding knowledge preferred', 'cr1.png'),
(101, 'Python', '7999', '426hr', 'Become a python Developer and learn how to build applications such as Swiggy, Quora, IMDB, and lots more. Start your python journey at Rs. 7,999 per month*. Eligibility: Bachelor?s Degree with 50%. Prior coding knowledge preferred', 'cr2.jpg'),
(102, 'Ruby', '4599', '287hr', 'Become a Ruby Developer and learn how to build applications such as  Quora, IMDB, and lots more. Start your Ruby journey at Rs. 4599 per month', 'cr3.jpg'),
(103, 'C', '4500', '3months', 'Candidates who wish to learn about software programming are eligible to do the certification in C language. C is a basic level programming language anyone can learn it. So, there is no specific eligibility criteria to be required in candidates for the C language Course.', 'cr4.jpg'),
(104, 'Software testing', '24699', '80hrs', 'This course explores testing techniques for obtaining that assurance in all stages of software testing, focusing on the creation and maintenance of test cases, procedures, and scenarios', 'cr5.jpg'),
(105, 'DataAnalaysis', '6789', '80hrs', 'This course explores techniques for obtaining that assurance in all stages of data analaysis, focusing on the creation and maintenance of test cases, procedures, and scenarios', 'cr6.png'),
(106, 'Perl', '4566', '75hrs', 'Candidates who wish to learn about software programming are eligible to do the certification in C language. C is a basic level programming language anyone can learn it. So, there is no specific eligibility criteria to be required in candidates for the C language Course.', 'cr7.jpg'),
(111, 'Frontend ', '6200', '20+hrs', 'I feel the curriculum is very extensive and covers everything from the basics in backend and frontend technologies. ', 'cr8.png'),
(112, 'Backend development', '6200', '35+hr', 'Being a backend develper feel the curriculum is very extensive and covers everything from the basics in backend technologies. ', 'cr9.png');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stid` int(11) NOT NULL,
  `stnm` varchar(100) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `fanm` varchar(100) NOT NULL,
  `manm` varchar(100) NOT NULL,
  `crnm` varchar(300) NOT NULL,
  `crid` int(11) NOT NULL,
  `feepay` varchar(11) NOT NULL,
  `duefee` varchar(11) NOT NULL,
  `pic` varchar(1000) NOT NULL,
  `fnmail` varchar(30) NOT NULL,
  `adds` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stid`, `stnm`, `mail`, `phno`, `fanm`, `manm`, `crnm`, `crid`, `feepay`, `duefee`, `pic`, `fnmail`, `adds`) VALUES
(109, 'Thiya', 'thiya@gmail.com', '9876543210', 'Baskaran', 'Sivakamiselvi', 'C', 103, '1000', '3500', 'download.png', 'baskaran@gmail.com', 'No-8,new aveneue,8'),
(115, 'Flora', 'flora@gmail.com', '9875643251', 'cccc', 'dddd', 'Frontend', 111, '4000', '2200', 'img8.png', 'cccc@gmail.com', 'N0-2,new avenue,chennai'),
(116, 'Komathi', 'komathi@gmail.com', '890765432', 'dddd', 'eeee', 'Python', 101, '3000', '4999', 'img9.jpg', 'dddd@gmail.com', 'N0-3,new street,chennai'),
(117, 'Hariharan', 'hariharan@gmail.com', '8984278917', 'abc', 'def', 'perl', 106, '3000', '1566', 'img3.png', 'abc@gmail.com', 'No-102,mh,chennai'),
(118, 'Karthick', 'karthik@gmail.com', '9042284657', 'Baskaran', 'selvi', 'Fullstack', 100, '3000', '2898', 'img1.jpg', 'baskaran@gmail.com', 'N0-22a,kamban nagar'),
(119, 'Preethika', 'preethika@gmail.com', '9087654678', 'www', 'xxx', 'Backend', 112, '3400', '2800', 'img10.jpg', 'www@gmail.com', 'N0-67/34,k.k nagar,chennai'),
(120, 'Chandru', 'chandru@gmail.com', '9876594325', 'YYYY', 'ZZZZZ', 'Data Analysis', 105, '3000', '3789', 'img5.jpg', 'YYYY@gmail.com', 'N0-10,K.H.nagar'),
(124, 'Nandhini', 'nandhini@gmail.com', '9087654367', 'TTTT', 'VVVV', 'C', 103, '2000', '2500', 'img11.png', 'TTTT@gmail.com', 'NO-22a,kk nagar,th street,chennai'),
(125, 'Reshika', 'reshi@gmail.com', '987567347', 'rrr', 'vvv', 'Python', 101, '4500', '3499', 'img12.jpg', 'rrr@gmail.com', 'NO-34/2,kamban street,chennai');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `email_id` varchar(300) NOT NULL,
  `pwd` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`email_id`, `pwd`) VALUES
('abc@gmail.com', '1234'),
('admin@gmail.com', '2345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`crid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `crid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
