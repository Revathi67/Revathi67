package mypack;

import javax.persistence.*;
@Entity
@Table(name="course")
public class course {
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int crid;

	@Column(name="crnm")
	private String crnm;
	
	@Column(name="desp")
	private String desp;
	@Column(name="cost")
	private String cost;
	
	
	@Column(name="duration")
	private String duration;
	
	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	@Column(name="pic")
	private String pic;
	
	
	
	public String toString()
	{
		return "\nCourse Id: "+getCrid()+"\nCourse Name : "+getCrnm()+"\nCost : "+getCost()+"\nDuration : "+getDuration()+"\nDecrption : "+getDesp()+"\nPic : "+getPic();	
	}
	
	public int getCrid() {
		return crid;
	}

	public void setCrid(int crid) {
		this.crid = crid;
	}

	public String getCrnm() {
		return crnm;
	}

	public void setCrnm(String crnm) {
		this.crnm = crnm;
	}

	public String getDesp() {
		return desp;
	}

	public void setDesp(String desp) {
		this.desp = desp;
		
		
	}
	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}


	

}
